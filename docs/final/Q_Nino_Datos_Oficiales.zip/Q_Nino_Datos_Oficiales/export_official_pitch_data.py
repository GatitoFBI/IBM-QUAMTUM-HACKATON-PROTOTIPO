"""Export the audited, narrowly selected official data used in the Q-Niño pitch.

The explicit year labels are the grouping key. No day/month is inferred.
Run from any directory; source paths resolve relative to this script.
"""
from pathlib import Path
from decimal import Decimal
from collections import defaultdict
import csv
import hashlib
import json
import re
import shutil
import sys
import zipfile

HERE = Path(__file__).resolve().parent
VERIFY_ONLY = "--verify-only" in sys.argv
RAW = HERE if (HERE / "originals").is_dir() else HERE.parent / "real-data-20261025"
OUT = HERE / "datos_oficiales_pitch"
if not VERIFY_ONLY:
    OUT.mkdir(exist_ok=True)
    (OUT / "originals").mkdir(exist_ok=True)

STATIONS = {
    "000207": ("Miraflores", "Piura", Decimal("1857.7")),
    "000132": ("Puerto Pizarro", "Tumbes", Decimal("2433.6")),
}
records, summaries, sources = [], [], []
for code, (station, region, expected) in STATIONS.items():
    name = f"senamhi_descarga_cod{code}_popup.html"
    source = RAW / "originals" / name
    text = source.read_text(errors="replace")
    match = re.search(r"categories\s*:\s*\[([^]]+)\]", text)
    labels = re.findall(r"\d{4}", match.group(1))
    values = None
    for match in re.finditer(r"name\s*:\s*'([^']+)'", text):
        if "Precip" in match.group(1):
            data_start = text.index("data:", match.end())
            start, end = text.index("[", data_start), text.index("]", data_start)
            values = [v.strip() for v in text[start + 1:end].split(",") if v.strip()]
            break
    assert values is not None and len(values) == len(labels)
    selected = [(i, value) for i, (year, value) in enumerate(zip(labels, values)) if year == "1998"]
    assert len(selected) == 365 and all(value != "null" for _, value in selected)
    total = sum(Decimal(value) for _, value in selected)
    assert total == expected
    url = f"https://www.senamhi.gob.pe/site/descarga-datos/descarga/?cod={code}"
    for order, (index, value) in enumerate(selected, start=1):
        records.append({"station": station, "region": region, "station_code": code,
                        "year_label": "1998", "order_within_year": order,
                        "source_series_index_0_based": index, "precipitation_mm": value,
                        "source_url": url, "source_file": "originals/" + name})
    summaries.append({"station": station, "region": region, "station_code": code,
                      "year": 1998, "precipitation_total_mm": str(total),
                      "observations": 365, "missing_values": 0,
                      "method": "own sum of daily values grouped by explicit year label",
                      "source_url": url})
    if not VERIFY_ONLY:
        shutil.copyfile(source, OUT / "originals" / name)
    sources.append({"file": "originals/" + name, "url": url,
                    "sha256": hashlib.sha256(source.read_bytes()).hexdigest()})

if VERIFY_ONLY:
    print(json.dumps({"status": "PASS", "rows": len(records), "summaries": summaries}, ensure_ascii=False))
    raise SystemExit(0)

for name, rows in [("precipitacion_1998.csv", records), ("resumen_1998.csv", summaries)]:
    with (OUT / name).open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)

enfen = RAW / "originals/enfen_comunicado_18-2026.pdf"
shutil.copyfile(enfen, OUT / "originals" / enfen.name)
sources.append({"file": "originals/" + enfen.name,
                "url": "https://enfen.imarpe.gob.pe/download/comunicado-oficial-enfen-n-18-2026/",
                "sha256": hashlib.sha256(enfen.read_bytes()).hexdigest()})

for name in ["FUENTES_OFICIALES_ES.txt", "modelo_y_fuentes_ES.txt", "SENAMHI_ANNUAL_CHECK.json"]:
    shutil.copyfile(HERE / name, OUT / name)
shutil.copyfile(RAW / "FACT_CHECKER_AUDIT.md", OUT / "AUDITORIA_COMPLETA.md")
shutil.copyfile(__file__, OUT / "export_official_pitch_data.py")

(OUT / "LEEME.txt").write_text(
    "Q-NIÑO | EVIDENCIA OFICIAL SELECCIONADA PARA EL PITCH\n"
    "Consulta: 25/10/2026. Datos SENAMHI históricos de 1998; contexto ENFEN de 16/10/2026.\n\n"
    "resumen_1998.csv: dos totales anuales calculados por nosotros desde observaciones oficiales.\n"
    "precipitacion_1998.csv: los 730 valores fuente, 365 por estación. order_within_year indica orden, "
    "no una fecha de observación publicada. No se infiere día/mes para los totales.\n"
    "originals/: los dos HTML de SENAMHI y el PDF oficial de ENFEN.\n"
    "MANIFEST.json: fuentes, huellas y tamaño de cada archivo del paquete.\n\n"
    "La auditoría completa incluye referencias a fuentes opcionales INDECI/CENEPRED que no forman "
    "parte de este paquete seleccionado. Los puntos usados aquí son C1, C2, C5 y la integridad C8. "
    "No se incluyen afirmaciones opcionales que quedaron sin auditar.\n\n"
    "Cada estación es una ubicación puntual, no un promedio regional. El histograma no publica "
    "una bandera de control de calidad. null significa faltante y nunca se convierte en cero.\n"
    "Los datos de lluvia sustentan el contexto. Las matrices F/D y los resultados actuales del "
    "optimizador siguen siendo sintéticos. Convertir lluvia a tiempos de viaje requiere calibración.\n"
    "El informe ENFEN contiene pronósticos; no son lluvia observada ni probabilidades de vías bloqueadas.\n\n"
    "Reproducción independiente: el script incluido usa solo la biblioteca estándar de Python. "
    "En la carpeta extraída, ejecutar: python3 export_official_pitch_data.py --verify-only . "
    "Lee los dos HTML originales, agrupa por año, verifica 365 valores sin faltantes y recalcula "
    "ambos totales sin depender de los CSV derivados.\n",
    encoding="utf-8",
)
entries = []
for path in sorted(OUT.rglob("*")):
    if path.is_file() and path.name != "MANIFEST.json":
        entries.append({"file": str(path.relative_to(OUT)), "bytes": path.stat().st_size,
                        "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
(OUT / "MANIFEST.json").write_text(json.dumps({"retrieved_date": "2026-10-25",
    "purpose": "audited official context for the pitch, not an operational solver dataset",
    "sources": sources, "files": entries}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

archive = HERE / "Q_Nino_Datos_Oficiales.zip"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as z:
    for path in sorted(OUT.rglob("*")):
        if path.is_file():
            z.write(path, "Q_Nino_Datos_Oficiales/" + str(path.relative_to(OUT)))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
print(json.dumps({"rows": len(records), "summaries": summaries, "zip": str(archive),
    "zip_bytes": archive.stat().st_size, "zip_sha256": hashlib.sha256(archive.read_bytes()).hexdigest()}, ensure_ascii=False))
